#!/bin/sh
#JAVA_HOME=/usr/java/jdk1.5.0_18
JAVA_HOME=/Library/Java/Home
CLASSPATH=$JAVA_HOME/lib/tools.jar
_RUNJAVA="$JAVA_HOME/bin/java"
JAVA_ENDORSED_DIRS=